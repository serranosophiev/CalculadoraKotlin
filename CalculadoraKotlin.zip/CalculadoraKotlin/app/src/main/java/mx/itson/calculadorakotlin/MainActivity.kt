package mx.itson.calculadorakotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity(), View.OnClickListener {

    //var = variable que va a cambiar su valor en diferentes ambientes
    //val = constante cuyo valor no cambia
    private lateinit var txtValor1 : EditText
    private lateinit var txtValor2 : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtValor1 =findViewById(R.id.valor1)
        txtValor2 =findViewById(R.id.valor2)
    }


    fun sumar (a:Int, b:Int) : Int {
        return a + b
    }
    fun sumar2 (a:Int, b:Int) = a + b

    override fun onClick(v: View?) {
        TODO("Not yet implemented")
    }
}